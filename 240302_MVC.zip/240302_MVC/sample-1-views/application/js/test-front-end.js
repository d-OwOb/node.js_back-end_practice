// alert("hihi");

// const div = document.getElementById("testDiv");
// div.innerText = "生成文字";

//語法 = JQuery (方便的js-frontend)
//進階=> react vue angular ...

$(function () {
  //   $("#testDiv").text("修改文字");

  setTimeout(() => {
    $("#testDiv").text("setTimeOut文字");
  }, 2000);

  $(".test-btn").click(() => {
    alert("準備開搶!!!");
    $.ajax({
      url: "/data",
      type: "GET",
    })
      .then((result) => {
        console.log(result);
        const output = result["age"];
        $("#testDiv").after(`<div style="margin: 10px;">${output}</div>`);
      })
      .catch((err) => {
        console.log(err);
      });
  });

  //目標 : 前端按按鈕後 發req 取得Object


  
});
