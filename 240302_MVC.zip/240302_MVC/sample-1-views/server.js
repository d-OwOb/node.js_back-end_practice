const express = require("express");
const path = require("path");
const app = express();
const hbs = require("hbs");
const portNum = 8088;
const dramasRouter = require("./router/dramas.js");
const aboutRouter = require("./router/about.js");

// 1.設定模板引擎 (讓express可解析html)
//hbs => handlebars 是一種引擎
//另一種=>pug
app.engine("html", hbs.__express);

// 2. 設定模板(template)位置
//講 html 在哪個資料夾
app.set("views", path.join(__dirname, "application", "views"));

// 3. 設定靜態檔
// 像是css js img 等檔案的位置
app.use(express.static(path.join(__dirname, "application")));

// 4. 改成回傳views的頁面
app.get("/", (req, res) => {
  //.render 回傳html頁面
  res.render("index.html");
});
//前端教學
app.get("/test", (req, res) => {
  res.render("template.html");
});

app.get("/data", (req, res) => {
  res.json({ name: "richard", age: 18 });
});

app.use("/dramas", dramasRouter);
app.use("/about", aboutRouter);

app.listen(portNum, () => {
  console.log(`Server is running at localhost:${portNum}`);
});
