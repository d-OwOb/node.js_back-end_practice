const express = require("express");
const router = express.Router();

router.get("/", (req, res) => {
  res.send("about's root dir");
});

router.get("/us", (req, res) => {
  res.render("aboutus.html");
});

module.exports = router;
