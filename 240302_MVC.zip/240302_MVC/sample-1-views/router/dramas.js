const { rejects } = require("assert");
const express = require("express");
const fs = require("fs");
const { resolve } = require("path");
const router = express.Router();

router.get("/", (req, res) => {
  res.send("drama's root dir");
});

router.get("/page", (req, res) => {
  res.render("dramas.html");
});

let readFilePromise = (datapath) => {
  return new Promise((resolve, rejects) => {
    fs.readFile(datapath, "utf-8", (err, data) => {
      if (err) {
        rejects(err);
      } else {
        resolve(JSON.parse(data));
      }
    });
  });
};

router.get("/getDramaListData?", async (req, res) => {
  //filter
  const cat = req.query.cat;
  //讀取資料
  try {
    const data = await readFilePromise("./models/sample2.json");

    if (cat === "全") res.json(data);
    else res.json(data.filter((item) => item.category === cat));
  } catch (error) {
    res.status(500).json({ message: "系統有問題" });
  }
});

module.exports = router;
